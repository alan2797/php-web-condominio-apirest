<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

define("FCM_SERVER", "https://fcm.googleapis.com/fcm/send");
define("API_KEY", "AAAAnkd-e0g:APA91bFsRSEZsNResaGHJXCQ4BiZgtKXXUBL7z9Tj1kK5viNtlxFvCYoq4dkmxzgv017OygBF2S3viljJ1gCxWK5vCr9NNnutUe3F5pvMm7zniVhio8pDLFsTE0HrZom-wkZ9sJBzHc4");
define("TITLE_APP", "AppCondominio");
    