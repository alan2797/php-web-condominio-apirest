<?php 
	class Conexion {
		public function conectar(){
			$host		= "localhost";
			$dbname 	= "id9900614_db_condominio";
			$usuario 	= "id9900614_alex";
			$password	= "123456";

			$link = new PDO("mysql:host=$host;dbname=$dbname",$usuario,$password);
			return $link;
		}
	}